#
# Copyright (C) 2025 The Android Open Source Project
# Copyright (C) 2025 SebaUbuntu's TWRP device tree generator
#
# SPDX-License-Identifier: Apache-2.0
#

add_lunch_combo omni_sl8541e_1h10-user
add_lunch_combo omni_sl8541e_1h10-userdebug
add_lunch_combo omni_sl8541e_1h10-eng
